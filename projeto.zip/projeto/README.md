# Cafeteria Grão & Cia

Trabalho final da disciplina **Front-End I** — Unilavras.

Site de tema livre desenvolvido com **HTML5** e **CSS3**, sem uso de frameworks,
apresentando a página de uma cafeteria fictícia.

## Estrutura do projeto

```
projeto/
├── index.html         # Página inicial
├── cardapio.html       # Página com o cardápio completo
├── style.css           # Estilos do site (CSS externo)
└── imagens/
    ├── xicara-cafe.svg
    ├── ambiente-cafeteria.svg
    └── doces.svg
```

## Conceitos aplicados

- Estrutura semântica com `header`, `nav`, `main`, `section`, `article`, `aside` e `footer`
- Textos com títulos, subtítulos, parágrafos, destaques e quebras de linha
- Imagens com `src` e `alt`, incluindo uma `figure` com `figcaption`
- Links externos, internos (entre páginas) e âncoras (dentro da mesma página)
- Listas ordenadas e não ordenadas
- Tabela com cabeçalho, várias linhas e colunas
- Seletores CSS de elemento, classe, ID, agrupado e universal
- Layout com `margin`, `padding`, `width`, cores e alinhamento
- Design responsivo com `media queries`

## Como visualizar

Basta abrir o arquivo `index.html` em qualquer navegador — não é necessário
nenhum servidor ou instalação.

## Autor

João Marcelo de Almeida Garcia
